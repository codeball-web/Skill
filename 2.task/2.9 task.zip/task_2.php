<?php

$x = 76;
$y = 8;

var_dump($x % $y);

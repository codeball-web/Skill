<?php

$a = 10;
$b = 2.5;
$e = 20;

$a + $b <= $e;
var_dump($a + $b <= $e);

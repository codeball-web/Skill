<?php

$q = 10;
$w = 10;
$w--;

var_dump($q != $w);

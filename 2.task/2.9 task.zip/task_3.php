<?php

$w = 2;
$q = 3;
$w++;


var_dump($w++ >= $q);
